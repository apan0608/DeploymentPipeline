#!/bin/sh

set -x

brew update
brew install zlib
brew install curl
brew install openssl
brew install libssh2
